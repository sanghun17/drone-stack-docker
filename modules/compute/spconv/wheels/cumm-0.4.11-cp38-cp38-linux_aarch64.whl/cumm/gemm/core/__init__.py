# Copyright 2021 Yan Yan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Union

from cumm.constants import CUTLASS_MODE
from cumm.dtypes import DType

from .metaarray import MetaArray, metaseq, seq


def array_type(dtype: Union[str, DType], count: int, align: int = 0):
    if not CUTLASS_MODE:
        return f"tv::array<{dtype}, {count}, {align}>"
    else:
        return f"cutlass::Array<{dtype}, {count}>"


def aligned_array_type(dtype: Union[str, DType], count: int, align: int = 0):
    if not CUTLASS_MODE:
        return f"tv::alignedarray<{dtype}, {count}, {align}>"
    else:
        return f"cutlass::AlignedArray<{dtype}, {count}, {align}>"
